﻿using System;

namespace OOP_1
{
    class Circle
    { 
        public double x, y, r;
        public Circle()
        {
            x = 0;
            y = 0;
            r = 0;
        }
        public Circle(double x, double y, double r)
        {
            this.x = x;
            this.y = y;
            this.r = r;
        }
        int GetQuadrant()
        {

        }

        public override string ToString()
        {
            return $"({x},{y},{r})";
        }
       public double AreaCalc(double r )
       {
            return Math.PI * Math.Pow(r, 2);
            
       }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" Введіть координати");
            double x = Convert.ToDouble(Console.ReadLine());
            double y = Convert.ToDouble(Console.ReadLine());
            double r = Convert.ToDouble(Console.ReadLine());
            Circle cirle = new Circle(x,y,r);           
            Console.WriteLine($" Задані координати {cirle}");
            Console.WriteLine(cirle.AreaCalc);
        }
    }
}
