﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OOP
{
    class Circle
    {
        double x, y, z;

    }
}
