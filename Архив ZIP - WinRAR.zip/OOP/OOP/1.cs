﻿
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_1
{
    class Adress
    {

        public int index { get; set; } = 18000;
        public string country{ get; set; } = "Ukraine";
        public string city { get; set; } = "Cherkago";
        public string street { get; set; } = "Rizdvyana";
        public int house{ get; set; } = 4;
        public int apartment { get; set; } = 10;



    }
    class Program
    {
        static void Main(string[] args)
        {
            Adress MyAdress = new Adress();
            Console.WriteLine("Index {0}\n Country {1}\n City " +
                "{2}\n Street{3}\n House{4}\n Apartment{5}",MyAdress.index,MyAdress.country,
                MyAdress.country,MyAdress.street,MyAdress.house,MyAdress.apartment);
            Console.ReadLine();
        }
    }
}
