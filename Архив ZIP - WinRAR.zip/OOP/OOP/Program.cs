﻿using System;

namespace OOP
{
    class Address 
    {
        public int index;
        public string country;
        public string city;
        public string street;
        public string house;
        public string apartament;


        public void GetInfo()
        {
            Console.WriteLine($"Идекс: {index}  Країна : {country} Мiсто:{city} Вулиця:{street} Будинок:{house} Номер:{apartament}");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Address info = new Address();           
            info.index = 242542;
            info.country = "Ukrain";
            info.city = "Cherkassy";
            info.street = "Narbytivska";
            info.house = "Number 198";
            info.apartament = "Number 83";
            info.GetInfo();
        }
    }
}
